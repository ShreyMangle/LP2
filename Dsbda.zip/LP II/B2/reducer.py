import sys

current = ""
count = 0

for line in sys.stdin:
    key, value = line.strip().split("\t")
    value = int(value)

    if key == current:
        count += value
    else:
        if current != "":
            print(current + "\t" + str(count))

        current = key
        count = value

if current != "":
    print(current + "\t" + str(count))

#cat $HADOOP_HOME/logs
#cat log.txt | python3 mapper.py | sort | python3 reducer.py