import sys

for line in sys.stdin:
    parts = line.strip().split()

    if len(parts) >= 3:
        print(parts[2] + "\t1")